﻿namespace Web.Models
{
    public class RegisterFuncionarioViewModel
    {
        public string Rut { get; set; }
        public string Nombre { get; set; }
        public string Especialidad { get; set; }
        public int TipoId { get; set; }
        public string NombreUsuario { get; set; }
        public string Password { get; set; }
        public int TallerId { get; set; }
    }
}