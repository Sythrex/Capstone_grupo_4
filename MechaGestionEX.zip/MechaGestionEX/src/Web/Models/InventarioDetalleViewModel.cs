﻿namespace Web.Models
{
    public class InventarioDetalleViewModel : InventarioViewModel
    {
        public int RepuestoUnidadesId { get; set; }
    }
}